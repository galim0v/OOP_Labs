#pragma once
#include <vector>
#include "Product_Galimov.h"
#include <fstream>

class Store
{
private:
	vector<Product_Galimov*> Products_Galimov;
public:
	void AddProduct(Product_Galimov& p);
	void OutputProducts();
	void ToFileProducts();
	void FromFileProducts();
	void ClearProducts();
};

