#include "Store_Galimov.h"


void Store::AddProduct(Product_Galimov& p)
{
	Products_Galimov.push_back(&p);
}

void Store::OutputProducts()
{
	for (auto i : Products_Galimov)
		(*i).OutputProduct();

	//for (auto productPtr : Products_Galimov)
	//{
	//	productPtr->OutputProduct();
	//}
}

void Store::ToFileProducts()
{
	ofstream fout;
	fout.open("ToFile.txt", ios_base::out);
	for (auto i : Products_Galimov)
		(*i).ToFileProduct(fout);
	fout.close();
}

void Store::FromFileProducts()
{
	ifstream fin;
	fin.open("FromFile.txt",ios_base::in);
	Product_Galimov*pr=new Product_Galimov;

	while (fin>>(*pr)) {			//������ ���������� ��������� ��������?
		//pr.FromFileProduct(fin); //����� �� ��� �������
		AddProduct(*pr);
		pr = new Product_Galimov;
		//delete pr;
	}
	fin.close();

	/*while (true) {
		Product pr;
		fin >> pr;

		if (fin.eof()) {
			break;
		}

		cout << pr << endl;
	}*/
}

void Store::ClearProducts()
{
	Products_Galimov.clear();
}
