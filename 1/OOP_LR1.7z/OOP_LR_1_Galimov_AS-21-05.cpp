﻿#include <iostream>
#include "Product_Galimov.h"
#include "Store_Galimov.h"
#include <string>
#include <fstream>

using namespace std;

void PrintMenu() {
	cout << "--------------------\n Select a menu item\n1. from the console\n2. to the console\n3. from the file\n4. to a file\n5. Clear\n0. Exit\n--------------------\n";
}

int main()
{

	//int a = 5; //&a предоставляет адрес в памяти, где хранится значение a.
	//int* b = &a; //b= указатель на целое число
	////Теперь указатель b указывает на тот же участок памяти, где хранится значение a.
	//cout << &a<<" "<<b<<" silki";
	//cout <<"\n"<< * b;
	//cout << "\n" << &b << " " << **(&b);


	size_t s = 0;
	Store st;
	Product_Galimov*pr;
	do {
		PrintMenu();
		cin >> s;

		switch (s) {
		case 0:
			exit(0);
			break;
		case 1:
			//нужно создать новую ссылку
			pr = new Product_Galimov;
			(*pr).InputProduct();
			st.AddProduct(*pr);
			//delete pr;
			break;
		case 2:
			st.OutputProducts();
			break;
		case 3:
			st.FromFileProducts();
			break;
		case 4:
			st.ToFileProducts();
			break;
		case 5:
			st.ClearProducts();
			break;
		default:
			cout << "Invalid value. Try again\n";
		}
	} while (s != 0);

	return 0;

}


//comments
//Product InputProduct() {
//	string n = "";
//	int pr = 0, w = 0, c = 0;
//	cout << "Input Product-Name: ";
//	getline(cin >> ws, n);
//	cout << "Input Product-Price: ";
//	cin >> pr;
//	cout << "Input Product-Weight: ";
//	cin >> w;
//	cout << "Input Product-Code: ";
//	cin >> c;
//	Product p(n, pr, w, c);
//	return p;
//}

//void OutputProduct(Product p) {
//	cout << p.GetName() << "\n" << p.GetPrice() << "\n" << p.GetWeight() << "\n" << p.GetCode();
//}

//void ToFileProduct(Product p) {
//	ofstream fout;
//	fout.open("ToFile.txt");
//	fout << p.GetName() << "\n" << p.GetPrice() << "\n" << p.GetWeight() << "\n" << p.GetCode();
//	fout.close();
//}

//Product FromFileProduct() {
//	string n;
//	int w, pr, c;
//	ifstream fin;
//	fin.open("FromFile.txt");
//	getline(fin >> ws, n);
//	fin >> pr;
//	fin >> w;
//	fin >> c;
//	fin.close();
//	Product p(n, pr, w, c);
//	return p;
//}